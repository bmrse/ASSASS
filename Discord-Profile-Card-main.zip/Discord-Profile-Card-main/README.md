<h1 align="center">Discord Profile Card With Webhook</h1>
<p align="center">
    <a href="https://github.com/McDaived/Discord-Profile-Card">
        <img src="https://github.com/McDaived/Discord-Profile-Card/assets/18085492/35ffced0-44dc-496c-88d2-a1c7a5be1d26" alt="Logo" width="500" height="100">
    </a>
<h4 align="center">An exact copy of discord profile card with 3 cards</h4>


## ![](https://github.com/McDaived/Discord-Profile-Card/assets/18085492/952742cf-9744-4ccb-9de1-766560ebae12)Features :

- Send message with webhook.
- With username badge hashtag.
- Add note.
- Photo profile & Animation banner.
- rolles & random roles.

## ![](https://github.com/McDaived/Discord-Profile-Card/assets/18085492/7a4879fd-97a1-4807-98e5-8f62137dee6e)ScreenShot :
- live Demo : [here](https://daived.me/Discord-Profile-Card)
![image](https://github.com/McDaived/Discord-Profile-Card/assets/18085492/841f9e27-96e5-4626-a6ee-d4558249468f)





